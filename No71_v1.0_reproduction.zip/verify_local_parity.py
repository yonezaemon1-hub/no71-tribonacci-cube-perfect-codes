"""Independent small-n exact-cover tests and n-uniform parity identity sanity checks.
Uses only Python standard library; a passing result is not a formal proof of all n.
"""
from itertools import combinations

def admissible(S,n):
    return all(not {i,i+1,i+2}.issubset(S) for i in range(1,n-1))

def vsets(n):
    return [frozenset(s) for k in range(n+1) for s in combinations(range(1,n+1),k) if admissible(set(s),n)]

def closed_ball(v, VV):
    return {u for u in VV if len(v ^ u) <= 1}

def perfect_code_existence_bruteforce(n):
    VV=set(vsets(n))
    balls={v:closed_ball(v,VV) for v in VV}
    covering={u:sorted((v for v in VV if u in balls[v]),key=lambda s:(len(s),tuple(sorted(s)))) for u in VV}
    def dfs(undominated, used):
        if not undominated:return tuple(used)
        u=min(undominated,key=lambda w:sum(1 for c in covering[w] if balls[c] <= undominated))
        for c in covering[u]:
            if balls[c] <= undominated:
                ans=dfs(undominated-balls[c], used+(c,))
                if ans is not None:return ans
        return None
    return dfs(VV,())

def fan(n):
    assert n >= 5 and n % 2 == 1
    P={2,n}; S={1,2,n}; L=set(range(4,n))
    assert admissible(P,n) and admissible(S,n)
    allowed={x for x in range(1,n+1) if x not in S and admissible(S|{x},n)}
    assert allowed==L,(n,allowed,L)
    assert len(L)==n-4 and len(L)%2==1
    for c in L:
        R=P|{c}
        assert admissible(R,n)
        assert {2,3}.issubset(R) is False
        for d in L-{c}:
            D=S|{d}
            assert admissible(D,n)
            assert len(R^D)==3  # c!=d, centres can coexist at distance 3
            # Candidate weight-5 center covering W_x must also cover another W_z.
            for x in L-{c,d}:
                W=S|{x}
                assert admissible(W,n)
                for z in L-{x}:
                    U=W|{z}
                    if admissible(U,n):
                        covered={t for t in L if len((S|{t})^U)==1}
                        assert covered=={x,z},(n,x,z,covered)
    return len(L)

def forbidden_graph(n,j):
    E=[frozenset(set(range(i,i+3))-{j}) for i in range(1,n-1) if j in range(i,i+3)]
    assert all(len(e)==2 for e in E)
    assert len(E)==(1 if j in (1,n) else (2 if j in (2,n-1) else 3))
    # F_j is acyclic: all nonempty subgraphs have a degree-one vertex.
    for count in range(1,1<<len(E)):
        sel=[E[i] for i in range(len(E)) if count>>i&1]
        deg={x:sum(x in e for e in sel) for e in sel for x in e}
        assert any(k%2 for k in deg.values())
    if j not in (1,n):
        assert any(a & b for a,b in combinations(E,2))


def all_matchings(vertices):
    """Enumerate perfect matchings on a tuple of distinct vertices."""
    vertices=tuple(vertices)
    if not vertices:
        yield frozenset()
        return
    a=vertices[0]
    for offset,b in enumerate(vertices[1:],start=1):
        rem=vertices[1:offset]+vertices[offset+1:]
        for tail in all_matchings(rem):
            yield frozenset([frozenset((a,b))]) | tail

def verify_matchings_count(n):
    total=0
    for j in range(1,n+1):
        X=tuple(a for a in range(1,n+1) if a!=j)
        forbidden=frozenset(frozenset(set(range(i,i+3))-{j})
                            for i in range(1,n-1) if j in (i,i+1,i+2))
        for M in all_matchings(X):
            total+=1
            for a in X:
                direct=sum(admissible({j,a,b},n) and
                           frozenset((a,b)) not in M
                           for b in X if b!=a)
                predicted=n-3-sum(a in edge for edge in (forbidden-M))
                assert direct==predicted,(n,j,a,direct,predicted,M)
    return total

def main():
    expected={1:True,2:False,3:True,4:False}
    for n,ans in expected.items():
        code=perfect_code_existence_bruteforce(n)
        assert (code is not None)==ans,(n,code)
        print('EXACT SMALL CASE PASS',n, 'exists',bool(code is not None), 'witness',code if code else '-')
    for n in range(5,102,2):
        for j in range(1,n+1):forbidden_graph(n,j)
    print('LOCAL ENDPOINT GRAPH PASS odd n=5..101')
    for n in range(5,31,2):
        p=fan(n)
        print('FAN PARITY PASS',n,'legal four-vertex extensions',p,'odd',p%2==1)
    # Nontrivial finite cross-check: independently enumerate all perfect matchings
    # for odd n=5,7,9 and compare the direct legal-triple count in Lemma 3.
    # This is supporting evidence, NOT a proof of the infinite-dimensional claim.
    for n in (5,7,9):
        count = verify_matchings_count(n)
        print('LEMMA3 DIRECT TRIPLE COUNT PASS', n, 'matchings checked', count)
    print('ALL V0.5 FINITE SANITY CHECKS PASS')
if __name__=='__main__':main()
