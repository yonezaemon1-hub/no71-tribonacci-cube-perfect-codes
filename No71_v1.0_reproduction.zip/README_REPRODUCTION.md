# Finite diagnostic reproducer

Run `python -B -I verify_local_parity.py` using Python 3.12+ (standard library only). End marker `ALL V0.5 FINITE SANITY CHECKS PASS`. The program checks exact small instances n=1..4, the endpoint graph through odd n=101, fan parity for odd n=5..29, and direct triple counts for n=5,7,9. This is not a formal proof for all n.

Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
